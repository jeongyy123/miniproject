from flask import Flask, render_template, request, redirect,url_for, session
import requests
#DB 기본 코드
import os
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash 

basedir = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] =\
        'sqlite:///' + os.path.join(basedir, 'database.db')

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    userEmail = db.Column(db.String(120), unique=True, nullable=False)
    userPw = db.Column(db.String(60), nullable=False)

    def __repr__(self):
        return f'{self.userEmail} {self.userPw}'

class Board(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ott = db.Column(db.String(200), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    price = db.Column(db.String(100), nullable=False)
    period = db.Column(db.String(100), nullable=False)
    contents = db.Column(db.String(10000), nullable=False)

with app.app_context():
    db.create_all()

# 메인화면(덕용님)
@app.route("/")
def home():
    return render_template('index.html')

# 로그인 기능(윤영님)
@app.route('/movie/login')
def movie_login():
    return render_template('login.html')

@app.route("/movie/register")
def movie_register():
    return render_template('register.html')

@app.route("/movie/register/create")
def movie_register_create ():
    userEmail_receive = request.args.get("userEmail")
    userPw_receive = request.args.get("userPw")

    user = User(userEmail=userEmail_receive, userPw=userPw_receive)
    db.session.add(user)
    db.session.commit()

    user1 = User.query.filter_by(userEmail=userEmail_receive).first()
    print(user1)
    
    return render_template('login.html', userEmail=userEmail_receive, data=user1 )

# 게시판 코드(정민님)
@app.route("/board/")
def board():
    board_list = Board.query.all()
    return render_template('board_list.html', data=board_list)

@app.route("/board/write/")
def board_detail():
    return render_template('board_write.html')

@app.route("/board/view/<board_id>")
def board_view(board_id):
    board_detail = Board.query.filter_by(id=board_id).first()
    print(board_detail.ott)
    return render_template('board_view.html', data=board_detail)

@app.route('/board/delete/<board_id>')
def board_delete(board_id):
    delete_data = Board.query.filter_by(id=board_id).first()
    db.session.delete(delete_data)
    db.session.commit()
    return redirect(url_for('board'))

@app.route('/board/create/', methods=['POST'])
def board_create():
    ott_receive = request.form.get('ott_select')
    title_receive = request.form.get("title")
    price_receive = request.form.get("price_select")
    period_receive = request.form.get("period_select")
    contents_receive = request.form.get("contents")
    
    board = Board(ott=ott_receive, title=title_receive, price=price_receive, period=period_receive, contents=contents_receive)
    db.session.add(board)
    db.session.commit()
    return redirect(url_for('board'))

# 랜덤 영화 포스터(현지님)

# 박스오피스 검색(아영님)
@app.route("/movie/search")
def movie_search():

    if request.args.get('query'):
        query = request.args.get('query')
    else:
        query = '20230930'    

    URL = f"http://kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchWeeklyBoxOfficeList.json?key=f5eef3421c602c6cb7ea224104795888&targetDt={query}"

    res = requests.get(URL)

    rjson = res.json()
    movie_list = rjson.get("boxOfficeResult").get("weeklyBoxOfficeList")

    return render_template("movie_search.html", data=movie_list)

if __name__ == "__main__":
    app.run(debug=True)